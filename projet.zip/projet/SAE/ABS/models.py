from django.db import models

class Enseignant(models.Model):
    nom_Enseignant = models.CharField(max_length=15) 
    prenom_Enseignant = models.CharField(max_length=15) 
    email_Enseignant = models.CharField(max_length=25) 
    
    def __str__(self):
        return f"nom : {self.nom_Enseignant} prénom : {self.prenom_Enseignant} @mail : {self.email_Enseignant}"

    def dico(self):
        return {"nom_Enseignant":self.nom_Enseignant, "prenom_Enseignant":self.prenom_Enseignant, "email_Enseignant":self.email_Enseignant}
    

##############################    
class Cours(models.Model):
    titre_Cours = models.CharField(max_length=100) 
    date_Cours = models.DateField(null=True, blank=True) 
    Enseignant_Cours = models.ForeignKey(Enseignant, on_delete=models.CASCADE) 
    durée_Cours = models.CharField(max_length=100, null=True, blank=True) 
    groups_Cours = models.ManyToManyField('Groupe')  

    def __str__(self):
        return f"titre du cours : {self.titre_Cours}"

    def dico(self):
        return {"titre_Cours":self.titre_Cours, "date_Cours":self.date_Cours, "Enseignant_Cours":self.Enseignant_Cours, "durée_Cours":self.durée_Cours, "groups_Cours":self.groups_Cours}
    
##############################   
class Etudiant(models.Model):
    nom = models.CharField(max_length=100)
    prenom = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    groupe = models.ForeignKey("Groupe",db_column="groupe_id", on_delete=models.CASCADE, related_name='etudiants')
    photo = models.ImageField(upload_to='photos/')

    def __str__(self):
        return self.nom
    
    
    def dico(self):
        return {"nom":self.nom, "prenom":self.prenom, "email":self.email, "groupe":self.groupe, "photo":self.photo}
    
    
##############################   
class Absence(models.Model):
    etudiant = models.ForeignKey(Etudiant,db_column="etudiant_id", on_delete=models.CASCADE, related_name='absences') 
    cours = models.ForeignKey(Cours,db_column="groupe_id", on_delete=models.CASCADE, related_name='absences')
    justifie = models.CharField(max_length=3, choices=[("OUI", "OUI"), ("NON", "NON")], default="NON")
    justification = models.CharField(max_length=100)

    def __str__(self):
        return self.justifie
    
    def dico(self):
        return {"etudiant":self.etudiant, "cours":self.cours, "justifie":self.justifie, "justification":self.justification}
    
##############################  
class Groupe(models.Model):
    nom = models.CharField(max_length=100)

    def __str__(self):
        return self.nom
    
    def dico(self):
        return {"nom":self.nom}