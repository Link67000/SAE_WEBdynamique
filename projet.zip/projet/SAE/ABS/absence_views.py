from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect
from .forms import AbsenceForm
from . import models
from .models import Absence

def ajout_Absence(request):
    if request.method == "POST":
        form = AbsenceForm(request.POST)
        return render(request, "Absence/ajout.html", {"form": form})
    else:
        form = AbsenceForm()  
        return render(request, "Absence/ajout.html", {"form": form})
    
def traitement(request):
    Absence_form = AbsenceForm(request.POST)
    if Absence_form.is_valid():
        Absence = Absence_form.save()
        return HttpResponseRedirect("/ABS/Absence/")
    else:
        return render(request, "Absence/ajout.html", {"form": Absence_form})

def index(request):
    liste = (models.Absence.objects.all())
    return render(request, "Absence/index.html", {"liste" : liste})

def affiche(request, id):
    absence = Absence.objects.get(pk=id)
    return render(request,"Absence/affiche.html", {"Absence" : absence})

def update(request,id):
    Absence = models.Absence.objects.get(pk=id)
    form = AbsenceForm(Absence.dico())
    return render(request, "Absence/ajout.html", {"form": form, "id": id})


def updatetraitement(request, id):
    form = AbsenceForm(request.POST)
    if form.is_valid():
        Absence = form.save(commit=False)
        Absence.id = id
        Absence.save()
        return HttpResponseRedirect("/ABS/Absence/") 
    else:
        return render(request, "Absence/ajout.html", {"form": form, "id": id})
    
def delete(request, id):
    Absence = models.Absence.objects.get(pk=id)
    Absence.delete()
    return HttpResponseRedirect("/ABS/Absence/")