from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect
from .forms import CoursForm
from . import models
from .models import Cours

def ajout_Cours(request):
    if request.method == "POST":
        form = CoursForm(request.POST)
        return render(request, "Cours/ajout.html", {"form": form})
    else:
        form = CoursForm()  
        return render(request, "Cours/ajout.html", {"form": form})
    
def traitement(request):
    Cours_form = CoursForm(request.POST)
    if Cours_form.is_valid():
        Cours = Cours_form.save()
        return HttpResponseRedirect("/ABS/Groupe/")
    else:
        return render(request, "Cours/ajout.html", {"form": Cours_form})

def index(request):
    liste = (models.Cours.objects.all())
    return render(request, "Cours/index.html", {"liste" : liste})

def affiche(request, id):
    cours = Cours.objects.get(pk=id)
    return render(request,"Cours/affiche.html", {"Cours" : cours})



def update(request,id):
    Cours = models.Cours.objects.get(pk=id)
    form = CoursForm(Cours.dico())
    return render(request, "Cours/ajout.html", {"form": form, "id": id})



def updatetraitement(request, id):
    cours = models.Cours.objects.get(pk=id)
    form = CoursForm(request.POST,instance=cours)
    if form.is_valid():
        form.save()
        return HttpResponseRedirect("/ABS/Cours/") 
    else:
        return render(request, "Cours/update.html", {"form": form, "id": id})
    
"""def updatetraitement(request, id):
    form = CoursForm(request.POST)
    if form.is_valid():
        Cours = form.save(commit=False)
        Cours.id = id
        Cours.save()
        return HttpResponseRedirect("/ABS/Cours/") 
    else:
        return render(request, "Cours/ajout.html", {"form": form, "id": id})"""
    
def delete(request, id):
    Cours = models.Cours.objects.get(pk=id)
    Cours.delete()
    return HttpResponseRedirect("/ABS/Cours/")