from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect
from .forms import EtudiantForm
from . import models
from .models import Etudiant

def ajout_Etudiant(request):
    if request.method == "POST":
        form = EtudiantForm(request.POST)
        return render(request, "Etudiant/ajout.html", {"form": form})
    else:
        form = EtudiantForm()  
        return render(request, "Etudiant/ajout.html", {"form": form})
    
def traitement(request):
    Etudiant_form = EtudiantForm(request.POST)
    if Etudiant_form.is_valid():
        Etudiant = Etudiant_form.save()
        return HttpResponseRedirect("/ABS/Etudiant/")
    else:
        return render(request, "Etudiant/ajout.html", {"form": Etudiant_form})

def index(request):
    liste = (models.Etudiant.objects.all())
    return render(request, "Etudiant/index.html", {"liste" : liste})

def affiche(request, id):
    etudiant = Etudiant.objects.get(pk=id)
    return render(request,"Etudiant/affiche.html", {"Etudiant" : etudiant})

def update(request,id):
    Etudiant = models.Etudiant.objects.get(pk=id)
    form = EtudiantForm(Etudiant.dico())
    return render(request, "Etudiant/ajout.html", {"form": form, "id": id})


def updatetraitement(request, id):
    form = EtudiantForm(request.POST)
    if form.is_valid():
        Etudiant = form.save(commit=False)
        Etudiant.id = id
        Etudiant.save()
        return HttpResponseRedirect("/ABS/Etudiant/") 
    else:
        return render(request, "Etudiant/ajout.html", {"form": form, "id": id})
    
def delete(request, id):
    Etudiant = models.Etudiant.objects.get(pk=id)
    Etudiant.delete()
    return HttpResponseRedirect("/ABS/Etudiant/")