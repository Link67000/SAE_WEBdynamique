from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponseRedirect
from .forms import AbsenceForm
from . import models
from .models import Absence, Etudiant, Cours

def ajout_Absence(request):
    if request.method == "POST":
        form = AbsenceForm(request.POST)
        return render(request, "Absence/ajout.html", {"form": form})
    else:
        form = AbsenceForm()  
        return render(request, "Absence/ajout.html", {"form": form})
    
def prefill_absence_form(request, etudiant_id, cours_id):
    etudiant = models.Etudiant.objects.get(pk=etudiant_id)
    cours = models.Cours.objects.get(pk=cours_id)
    initial_data = {
        'etudiant': etudiant,
        'cours': cours,
        'justifie': 'NON',
        'justification': 'Aucune'
    }
    form = AbsenceForm(initial=initial_data)
    return render(request, 'Absence/ajout.html', {'form': form, 'etudiant': etudiant, "cours_id": cours_id})

def traitement(request, id):
    Absence_form = AbsenceForm(request.POST)
    if Absence_form.is_valid():
        Absence = Absence_form.save()
        return HttpResponseRedirect(f"/ABS/afficheCours/{id}/")
    else:
        return render(request, "Absence/ajout.html", {"form": Absence_form})

def index(request):
    liste = models.Absence.objects.all()
    return render(request, "Absence/index.html", {"liste" : liste})

def affiche(request, id):
    absence = Absence.objects.get(pk=id)
    liste = (models.Absence.objects.all())
    return render(request,"Absence/affiche.html", {"Absence" : absence, "liste":liste})

def update(request,id):
    Absence = models.Absence.objects.get(pk=id)
    form = AbsenceForm(Absence.dico())
    return render(request, "Absence/ajout.html", {"form": form, "id": id})


def updatetraitement(request, id):
    form = AbsenceForm(request.POST)
    if form.is_valid():
        Absence = form.save(commit=False)
        Absence.id = id
        Absence.save()
        return HttpResponseRedirect("/ABS/Absence/") 
    else:
        return render(request, "Absence/ajout.html", {"form": form, "id": id})
    
def delete(request, id):
    Absence = models.Absence.objects.get(pk=id)
    Absence.delete()
    return HttpResponseRedirect(f"/ABS/afficheEtudiant/{Absence.etudiant.id}/")



