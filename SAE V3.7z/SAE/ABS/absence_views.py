from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponseRedirect
from .forms import AbsenceForm
from . import models
from .models import Absence, Etudiant, Cours

def ajout_Absence(request, id):
    if request.method == "POST":
        form = AbsenceForm(request.POST)
        return render(request, "Absence/ajout.html", {"form": form})
    else:
        form = AbsenceForm()  
        return render(request, "Absence/ajout.html", {"form": form})
    
def prefill_absence_form(request, etudiant_id, cours_id):
    etudiant = get_object_or_404(Etudiant, pk=etudiant_id)
    cours = get_object_or_404(Cours, pk=cours_id)
    initial_data = {
        'etudiant': etudiant,
        'cours': cours,
        'justifie': 'NON',
        'justification': ''
    }
    form = AbsenceForm(initial=initial_data)
    
    if request.method == 'POST':
        form = AbsenceForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect("/ABS/afficheCours/{cours_id}")  # Replace 'some_view' with the name of the view you want to redirect to

    return render(request, 'Absence/ajout.html', {'form': form, 'etudiant': etudiant, "cours_id":cours_id})


def traitement(request):
    Absence_form = AbsenceForm(request.POST)
    if Absence_form.is_valid():
        Absence = Absence_form.save()
        return HttpResponseRedirect("/ABS/Absence/")
    else:
        return render(request, "Absence/ajout.html", {"form": Absence_form})

def index(request):
    liste = (models.Absence.objects.all())
    return render(request, "Absence/index.html", {"liste" : liste})

def affiche(request, id):
    absence = Absence.objects.get(pk=id)
    liste = (models.Absence.objects.all())
    return render(request,"Absence/affiche.html", {"Absence" : absence, "liste":liste})

def update(request,id):
    Absence = models.Absence.objects.get(pk=id)
    form = AbsenceForm(Absence.dico())
    return render(request, "Absence/ajout.html", {"form": form, "id": id})


def updatetraitement(request, id):
    form = AbsenceForm(request.POST)
    if form.is_valid():
        Absence = form.save(commit=False)
        Absence.id = id
        Absence.save()
        return HttpResponseRedirect("/ABS/Absence/") 
    else:
        return render(request, "Absence/ajout.html", {"form": form, "id": id})
    
def delete(request, id):
    Absence = models.Absence.objects.get(pk=id)
    Absence.delete()
    return HttpResponseRedirect("/ABS/Absence/")